---
name: Technical Minimalism
colors:
  surface: '#f9f9ff'
  surface-dim: '#d0daef'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff3ff'
  surface-container: '#e6eeff'
  surface-container-high: '#dee9fd'
  surface-container-highest: '#d9e3f7'
  on-surface: '#121c2a'
  on-surface-variant: '#444748'
  inverse-surface: '#273140'
  inverse-on-surface: '#ebf1ff'
  outline: '#747878'
  outline-variant: '#c4c7c7'
  surface-tint: '#5f5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1c1b1b'
  on-primary-container: '#858383'
  inverse-primary: '#c8c6c5'
  secondary: '#006399'
  on-secondary: '#ffffff'
  secondary-container: '#7bc2ff'
  on-secondary-container: '#004f7b'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#00210b'
  on-tertiary-container: '#49935c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c8c6c5'
  on-primary-fixed: '#1c1b1b'
  on-primary-fixed-variant: '#474646'
  secondary-fixed: '#cde5ff'
  secondary-fixed-dim: '#94ccff'
  on-secondary-fixed: '#001d32'
  on-secondary-fixed-variant: '#004b74'
  tertiary-fixed: '#a6f4b5'
  tertiary-fixed-dim: '#8bd79b'
  on-tertiary-fixed: '#00210b'
  on-tertiary-fixed-variant: '#005226'
  background: '#f9f9ff'
  on-background: '#121c2a'
  surface-variant: '#d9e3f7'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 17px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-mono-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.06em
  label-mono-xs:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.08em
  code-inline:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system reflects a restrained, highly engineered aesthetic built for an academic and engineering personal publishing space. The tone communicates disciplined clarity, technical precision, and intellectual rigor. It evokes the feeling of high-spec documentation systems, clean developer tooling interfaces, and minimalist editorial journals.

Key tenets:
- **Exactness over Ornamentation:** Visual rhythm is enforced through strict grid alignment, structural hairline rules, and proportional type hierarchies rather than heavy decoration.
- **Engineered Restraint:** Ample whitespace is paired with dense, informative metadata (timestamps, commit hashes, tag pills, execution times).
- **Subtle Modernism:** A pure white foundation accented by pale tonal containers and crisp monospaced tracking elements.

## Colors

The palette relies on absolute contrast and delicate structural separation:

- **Base Canvas:** Pure white (`#FFFFFF`) forms the foundational surface, ensuring unmatched clarity.
- **Text & Headlines:** Primary titles, structural glyphs, and high-impact values use solid near-black (`#111111`). General body copy uses deep neutral gray (`#374151`) to balance readability with a softer reading contrast. Subtle captions and metadata sit at `#6B7280`.
- **Surfaces & Rules:** Card fills and interactive surface tiers default to subtle off-white/gray (`#F8F9FA`). Spatial partitioning relies on crisp 1px borders colored in micro-gray (`#E5E7EB`).
- **Semantic Accents:** 
  - *Engineering & Systems (Sky):* Surface `#E0F2FE` with ink `#0369A1` for networking, architecture, and kernel topics.
  - *Algorithms & Completed (Mint):* Surface `#E6F4EA` with ink `#166534` for stable builds, algorithmic optimizations, and verification states.
  - *Research & Theory (Lavender):* Surface `#F3E8FF` with ink `#6B21A8` for theoretical CS, mathematics, and draft reflections.

## Typography

The typographic hierarchy pairs the utilitarian precision of Inter with the structured cadence of JetBrains Mono.

- **Headlines:** Set in Inter with tight negative tracking (`-0.02em` to `-0.03em`) and medium-to-semibold weights, establishing crisp technical authority without feeling aggressive.
- **Body Text:** Engineered for long-form technical readability. The body sizing (`15px` - `17px`) carries generous line-height (`1.6x` to `1.65x`) to prevent eye fatigue during dense code-and-prose breakdowns.
- **Monospace Elements & Overlines:** JetBrains Mono is deployed for metadata, section indexing (e.g., `01 // ARCHITECTURE`), code blocks, timestamps, and tags. All categorical labels utilize uppercase transform with expanded tracking (`0.06em` to `0.08em`).

## Elevation & Depth

This system avoids blurred drop shadows and skeuomorphic gradients entirely, choosing planar architectural depth:

- **Flat Micro-Borders:** Layering and boundaries are established exclusively via `1px solid #E5E7EB` borders.
- **Surface Tiering:**
  - `Level 0 (Canvas):` Pure White (`#FFFFFF`).
  - `Level 1 (Panels & Cards):` Subtle Muted Gray (`#F8F9FA`) enclosed in a `1px` border.
  - `Level 2 (Hover/Active):` Solid White (`#FFFFFF`) with a slightly darkened border transition to `#D1D5DB`.
- **Code & Callout Insets:** Terminal panels and blockquotes utilize `#F8F9FA` or dark code blocks `#111111` with inset hairline framing.

## Shapes

The geometric form factor is soft yet architectural (`roundedness: 1`):

- **Cards, Code Blocks, and Inputs:** Use a disciplined 4px radius (`0.25rem`), keeping shapes crisp, sharp, and structured like technical instruments.
- **Pills and Status Indicators:** Chips and tags use a fully rounded border radius (9999px) to distinctly separate metadata elements from functional content boxes and action surfaces.

## Components

### Buttons
- **Primary:** Background `#111111`, text `#FFFFFF`, 4px border radius. Hover state lightens subtly to `#262626`. Padding: 8px 16px. Font: Inter Medium 13px.
- **Secondary / Ghost:** Background transparent, border `1px solid #E5E7EB`, text `#111111`. Hover fills with `#F8F9FA`.
- **Minimal Text Action:** Monospaced label (`JetBrains Mono`), uppercase, 11px, with trailing character `→` that shifts +2px on hover.

### Chips & Tags
- Height: 22px, inline-flex, border radius 9999px.
- Typography: `label-mono-xs` (10px uppercase, letter-spacing `0.08em`).
- Padding: 2px 8px.
- Variants:
  - *Engineering:* Background `#E0F2FE`, text `#0369A1`.
  - *Algorithms:* Background `#E6F4EA`, text `#166534`.
  - *Theory:* Background `#F3E8FF`, text `#6B21A8`.
  - *Default:* Background `#F3F4F6`, text `#4B5563`.

### Cards & Post Previews
- Background: `#F8F9FA` or `#FFFFFF` bounded by `1px solid #E5E7EB`.
- Internal padding: 20px (Desktop), 16px (Mobile).
- Structure: Monospace timestamp and tag line at the top, followed by `headline-sm`, trailing summary in `body-sm`, and an optional right-aligned metadata counter.
- Interaction: On hover, border color transitions to `#9CA3AF`.

### Lists
- Articles and index lists render as borderless, flat line items divided by `1px solid #E5E7EB`.
- Layout: Date (`label-mono-sm` in `#6B7280`, fixed 100px width), title (`Inter 15px`, bolding on hover), and reading duration or category right-aligned.

### Code Blocks & Inlines
- Inline Code: Background `#F3F4F6`, border `1px solid #E5E7EB`, color `#111111`, font `JetBrains Mono`, padding 2px 5px, radius 3px.
- Syntax Blocks: Header containing file name and copy button separated by a bottom hairline border; editor body in `#111111` or `#FAFAFA` with monospace text at 13px / 20px line-height.

### Inputs & Search
- Background: `#FFFFFF`, border `1px solid #E5E7EB`, radius 4px.
- Padding: 8px 12px.
- Focus state: Border color jumps directly to `#111111` with no focus ring blur, preserving clean lines.